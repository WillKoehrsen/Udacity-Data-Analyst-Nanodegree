All of the audit scipts included functions used to audit the data as well as cleaning functions that were called by the dataToCSV.py script.
The dataToCSV.py script is a heavily modified version of the data.py script written during the OpenStreetMap case study and converts the OpenStreetMap XML file to CSV files. 
The audit scripts are original with the exception of the audit_street_types.py script which is an altered version of that created during the problem set for the "Improving Street Names" question.
The mappings.py script contains the mappings implemented by the cleaning functions. 
All of my work was documented in the Jupyter Notebook and the Notebook additionally contains a few short snippets of code used to execute SQL queries and create two graphs.
Any sources used in this report are linked to in the Jupyter Notebook and of course I must give credit to the Udacity Course as well!